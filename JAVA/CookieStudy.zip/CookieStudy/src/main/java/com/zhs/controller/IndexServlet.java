package com.zhs.controller;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class IndexServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userName,money;
        //先获取来自传输过来的参数
        userName = request.getParameter("userName");
        money = request.getParameter("money");

        //将用户传递过来的参数作为cookie来保存,由于一个cookie只能携带一对键值对，所以创建两个
        Cookie nameCookie = new Cookie("username", userName);
        Cookie moneyCookie = new Cookie("money",money);
        //将cookie添加到回复的response里，等待发送的时候推回去
        response.addCookie(nameCookie);
        response.addCookie(moneyCookie);
        //通过请求转发方案设置需要转发到的网页
        RequestDispatcher report = request.getRequestDispatcher("/orderPage.html");
        //开始转发，并携带用户的请求对象和响应对象，此时用户的响应对象将携带新实例的两个cookie对象返回
        report.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
