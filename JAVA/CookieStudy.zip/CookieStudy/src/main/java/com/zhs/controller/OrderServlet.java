package com.zhs.controller;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

public class OrderServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置菜价
        int shuijiao = 30;
        int miantiao = 20;
        int gaifan = 15;
        String name;
        int money = 0;
        int banlance = 0;
        int consume = 0;
        //获取用户选择的点餐内容
        response.setContentType("text/html;charset=utf-8");
        PrintWriter writer = response.getWriter();
        String food = request.getParameter("food");
        //用户消费点单之后，cookie里携带的金额也会改变，修改cookie值的方法就是替换他，新建一个cookie然后替换原cookie
        Cookie newCookie = null;
        //获取所有cookie对象，（拆箱操作）
        Cookie cookieArrayList[] = request.getCookies();
        //遍历所有cookie，for循环左边定义一个变量，然后右边放上数组，每次取出一个，然后将对象放到cool里面，从头循环到尾
        for (Cookie cool : cookieArrayList) {

            //获取每次循环里cookie的键和值
            String cookieName = cool.getName();
            String cookieValue = cool.getValue();
            //如果这个cookie的键等于我们设置的cookie时的键，这个cookie就是保存userName的
            if ("userName".equals(cookieName)) {
                name = cookieValue;
            }

            if ("money".equals(cookieName)) {

                //做强转
                money = Integer.valueOf(cookieValue);
                System.out.println("money"+money);
                //确定用户的姓名和余额之后，就可以判断用户点的什么，从而对金额做操作
                if ("水饺".equals(food)) {

                    consume = shuijiao;
                    if (money < shuijiao) {
                        writer.print("你的钱不够");
                    }else if (money > shuijiao){
                        banlance = money - shuijiao;
                        newCookie = new Cookie("money", banlance + "");
                    }
                }
                if ("面条".equals(food)) {
                    consume = miantiao;
                    if (money < miantiao) {
                        writer.print("你的钱不够");
                    }else if (money > miantiao){
                        banlance = money - miantiao;
                        newCookie = new Cookie("money", banlance + "");
                    }
                }
                if ("盖浇饭".equals(food)) {
                    consume = gaifan;
                    if (money < gaifan) {
                        writer.print("你的钱不够");
                    }else if (money > gaifan){
                        banlance = money - gaifan;
                        newCookie = new Cookie("money", banlance + "");

                    }
                }

            }
        }

        //将新cookie放入响应对象里，但是这个cookie的键还是food所以他会替换掉老cookie的值
        response.addCookie(newCookie);
        writer.print("余额是："+ banlance + "，本次消费："+consume);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
